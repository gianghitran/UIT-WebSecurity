.class public final Landroid/support/design/R$dimen;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/design/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "dimen"
.end annotation


# static fields
.field public static final abc_action_bar_content_inset_material:I = 0x7f070000

.field public static final abc_action_bar_content_inset_with_nav:I = 0x7f070001

.field public static final abc_action_bar_default_height_material:I = 0x7f070002

.field public static final abc_action_bar_default_padding_end_material:I = 0x7f070003

.field public static final abc_action_bar_default_padding_start_material:I = 0x7f070004

.field public static final abc_action_bar_elevation_material:I = 0x7f070005

.field public static final abc_action_bar_icon_vertical_padding_material:I = 0x7f070006

.field public static final abc_action_bar_overflow_padding_end_material:I = 0x7f070007

.field public static final abc_action_bar_overflow_padding_start_material:I = 0x7f070008

.field public static final abc_action_bar_progress_bar_size:I = 0x7f070009

.field public static final abc_action_bar_stacked_max_height:I = 0x7f07000a

.field public static final abc_action_bar_stacked_tab_max_width:I = 0x7f07000b

.field public static final abc_action_bar_subtitle_bottom_margin_material:I = 0x7f07000c

.field public static final abc_action_bar_subtitle_top_margin_material:I = 0x7f07000d

.field public static final abc_action_button_min_height_material:I = 0x7f07000e

.field public static final abc_action_button_min_width_material:I = 0x7f07000f

.field public static final abc_action_button_min_width_overflow_material:I = 0x7f070010

.field public static final abc_alert_dialog_button_bar_height:I = 0x7f070011

.field public static final abc_button_inset_horizontal_material:I = 0x7f070012

.field public static final abc_button_inset_vertical_material:I = 0x7f070013

.field public static final abc_button_padding_horizontal_material:I = 0x7f070014

.field public static final abc_button_padding_vertical_material:I = 0x7f070015

.field public static final abc_cascading_menus_min_smallest_width:I = 0x7f070016

.field public static final abc_config_prefDialogWidth:I = 0x7f070017

.field public static final abc_control_corner_material:I = 0x7f070018

.field public static final abc_control_inset_material:I = 0x7f070019

.field public static final abc_control_padding_material:I = 0x7f07001a

.field public static final abc_dialog_fixed_height_major:I = 0x7f07001b

.field public static final abc_dialog_fixed_height_minor:I = 0x7f07001c

.field public static final abc_dialog_fixed_width_major:I = 0x7f07001d

.field public static final abc_dialog_fixed_width_minor:I = 0x7f07001e

.field public static final abc_dialog_list_padding_bottom_no_buttons:I = 0x7f07001f

.field public static final abc_dialog_list_padding_top_no_title:I = 0x7f070020

.field public static final abc_dialog_min_width_major:I = 0x7f070021

.field public static final abc_dialog_min_width_minor:I = 0x7f070022

.field public static final abc_dialog_padding_material:I = 0x7f070023

.field public static final abc_dialog_padding_top_material:I = 0x7f070024

.field public static final abc_dialog_title_divider_material:I = 0x7f070025

.field public static final abc_disabled_alpha_material_dark:I = 0x7f070026

.field public static final abc_disabled_alpha_material_light:I = 0x7f070027

.field public static final abc_dropdownitem_icon_width:I = 0x7f070028

.field public static final abc_dropdownitem_text_padding_left:I = 0x7f070029

.field public static final abc_dropdownitem_text_padding_right:I = 0x7f07002a

.field public static final abc_edit_text_inset_bottom_material:I = 0x7f07002b

.field public static final abc_edit_text_inset_horizontal_material:I = 0x7f07002c

.field public static final abc_edit_text_inset_top_material:I = 0x7f07002d

.field public static final abc_floating_window_z:I = 0x7f07002e

.field public static final abc_list_item_padding_horizontal_material:I = 0x7f07002f

.field public static final abc_panel_menu_list_width:I = 0x7f070030

.field public static final abc_progress_bar_height_material:I = 0x7f070031

.field public static final abc_search_view_preferred_height:I = 0x7f070032

.field public static final abc_search_view_preferred_width:I = 0x7f070033

.field public static final abc_seekbar_track_background_height_material:I = 0x7f070034

.field public static final abc_seekbar_track_progress_height_material:I = 0x7f070035

.field public static final abc_select_dialog_padding_start_material:I = 0x7f070036

.field public static final abc_switch_padding:I = 0x7f070037

.field public static final abc_text_size_body_1_material:I = 0x7f070038

.field public static final abc_text_size_body_2_material:I = 0x7f070039

.field public static final abc_text_size_button_material:I = 0x7f07003a

.field public static final abc_text_size_caption_material:I = 0x7f07003b

.field public static final abc_text_size_display_1_material:I = 0x7f07003c

.field public static final abc_text_size_display_2_material:I = 0x7f07003d

.field public static final abc_text_size_display_3_material:I = 0x7f07003e

.field public static final abc_text_size_display_4_material:I = 0x7f07003f

.field public static final abc_text_size_headline_material:I = 0x7f070040

.field public static final abc_text_size_large_material:I = 0x7f070041

.field public static final abc_text_size_medium_material:I = 0x7f070042

.field public static final abc_text_size_menu_header_material:I = 0x7f070043

.field public static final abc_text_size_menu_material:I = 0x7f070044

.field public static final abc_text_size_small_material:I = 0x7f070045

.field public static final abc_text_size_subhead_material:I = 0x7f070046

.field public static final abc_text_size_subtitle_material_toolbar:I = 0x7f070047

.field public static final abc_text_size_title_material:I = 0x7f070048

.field public static final abc_text_size_title_material_toolbar:I = 0x7f070049

.field public static final compat_button_inset_horizontal_material:I = 0x7f07004e

.field public static final compat_button_inset_vertical_material:I = 0x7f07004f

.field public static final compat_button_padding_horizontal_material:I = 0x7f070050

.field public static final compat_button_padding_vertical_material:I = 0x7f070051

.field public static final compat_control_corner_material:I = 0x7f070052

.field public static final design_appbar_elevation:I = 0x7f070053

.field public static final design_bottom_navigation_active_item_max_width:I = 0x7f070054

.field public static final design_bottom_navigation_active_text_size:I = 0x7f070055

.field public static final design_bottom_navigation_elevation:I = 0x7f070056

.field public static final design_bottom_navigation_height:I = 0x7f070057

.field public static final design_bottom_navigation_item_max_width:I = 0x7f070058

.field public static final design_bottom_navigation_item_min_width:I = 0x7f070059

.field public static final design_bottom_navigation_margin:I = 0x7f07005a

.field public static final design_bottom_navigation_shadow_height:I = 0x7f07005b

.field public static final design_bottom_navigation_text_size:I = 0x7f07005c

.field public static final design_bottom_sheet_modal_elevation:I = 0x7f07005d

.field public static final design_bottom_sheet_peek_height_min:I = 0x7f07005e

.field public static final design_fab_border_width:I = 0x7f07005f

.field public static final design_fab_elevation:I = 0x7f070060

.field public static final design_fab_image_size:I = 0x7f070061

.field public static final design_fab_size_mini:I = 0x7f070062

.field public static final design_fab_size_normal:I = 0x7f070063

.field public static final design_fab_translation_z_pressed:I = 0x7f070064

.field public static final design_navigation_elevation:I = 0x7f070065

.field public static final design_navigation_icon_padding:I = 0x7f070066

.field public static final design_navigation_icon_size:I = 0x7f070067

.field public static final design_navigation_max_width:I = 0x7f070068

.field public static final design_navigation_padding_bottom:I = 0x7f070069

.field public static final design_navigation_separator_vertical_padding:I = 0x7f07006a

.field public static final design_snackbar_action_inline_max_width:I = 0x7f07006b

.field public static final design_snackbar_background_corner_radius:I = 0x7f07006c

.field public static final design_snackbar_elevation:I = 0x7f07006d

.field public static final design_snackbar_extra_spacing_horizontal:I = 0x7f07006e

.field public static final design_snackbar_max_width:I = 0x7f07006f

.field public static final design_snackbar_min_width:I = 0x7f070070

.field public static final design_snackbar_padding_horizontal:I = 0x7f070071

.field public static final design_snackbar_padding_vertical:I = 0x7f070072

.field public static final design_snackbar_padding_vertical_2lines:I = 0x7f070073

.field public static final design_snackbar_text_size:I = 0x7f070074

.field public static final design_tab_max_width:I = 0x7f070075

.field public static final design_tab_scrollable_min_width:I = 0x7f070076

.field public static final design_tab_text_size:I = 0x7f070077

.field public static final design_tab_text_size_2line:I = 0x7f070078

.field public static final disabled_alpha_material_dark:I = 0x7f070079

.field public static final disabled_alpha_material_light:I = 0x7f07007a

.field public static final fastscroll_default_thickness:I = 0x7f07007c

.field public static final fastscroll_margin:I = 0x7f07007d

.field public static final fastscroll_minimum_range:I = 0x7f07007e

.field public static final highlight_alpha_material_colored:I = 0x7f07007f

.field public static final highlight_alpha_material_dark:I = 0x7f070080

.field public static final highlight_alpha_material_light:I = 0x7f070081

.field public static final hint_alpha_material_dark:I = 0x7f070082

.field public static final hint_alpha_material_light:I = 0x7f070083

.field public static final hint_pressed_alpha_material_dark:I = 0x7f070084

.field public static final hint_pressed_alpha_material_light:I = 0x7f070085

.field public static final item_touch_helper_max_drag_scroll_per_frame:I = 0x7f070086

.field public static final item_touch_helper_swipe_escape_max_velocity:I = 0x7f070087

.field public static final item_touch_helper_swipe_escape_velocity:I = 0x7f070088

.field public static final notification_action_icon_size:I = 0x7f07008c

.field public static final notification_action_text_size:I = 0x7f07008d

.field public static final notification_big_circle_margin:I = 0x7f07008e

.field public static final notification_content_margin_start:I = 0x7f07008f

.field public static final notification_large_icon_height:I = 0x7f070090

.field public static final notification_large_icon_width:I = 0x7f070091

.field public static final notification_main_column_padding_top:I = 0x7f070092

.field public static final notification_media_narrow_margin:I = 0x7f070093

.field public static final notification_right_icon_size:I = 0x7f070094

.field public static final notification_right_side_padding_top:I = 0x7f070095

.field public static final notification_small_icon_background_padding:I = 0x7f070096

.field public static final notification_small_icon_size_as_large:I = 0x7f070097

.field public static final notification_subtext_size:I = 0x7f070098

.field public static final notification_top_pad:I = 0x7f070099

.field public static final notification_top_pad_large_text:I = 0x7f07009a

.field public static final tooltip_corner_radius:I = 0x7f0700a2

.field public static final tooltip_horizontal_padding:I = 0x7f0700a3

.field public static final tooltip_margin:I = 0x7f0700a4

.field public static final tooltip_precise_anchor_extra_offset:I = 0x7f0700a5

.field public static final tooltip_precise_anchor_threshold:I = 0x7f0700a6

.field public static final tooltip_vertical_padding:I = 0x7f0700a7

.field public static final tooltip_y_offset_non_touch:I = 0x7f0700a8

.field public static final tooltip_y_offset_touch:I = 0x7f0700a9


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 496
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
