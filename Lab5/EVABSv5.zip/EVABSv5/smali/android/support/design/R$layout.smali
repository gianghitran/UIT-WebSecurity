.class public final Landroid/support/design/R$layout;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/design/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "layout"
.end annotation


# static fields
.field public static final abc_action_bar_title_item:I = 0x7f0c0000

.field public static final abc_action_bar_up_container:I = 0x7f0c0001

.field public static final abc_action_bar_view_list_nav_layout:I = 0x7f0c0002

.field public static final abc_action_menu_item_layout:I = 0x7f0c0003

.field public static final abc_action_menu_layout:I = 0x7f0c0004

.field public static final abc_action_mode_bar:I = 0x7f0c0005

.field public static final abc_action_mode_close_item_material:I = 0x7f0c0006

.field public static final abc_activity_chooser_view:I = 0x7f0c0007

.field public static final abc_activity_chooser_view_list_item:I = 0x7f0c0008

.field public static final abc_alert_dialog_button_bar_material:I = 0x7f0c0009

.field public static final abc_alert_dialog_material:I = 0x7f0c000a

.field public static final abc_alert_dialog_title_material:I = 0x7f0c000b

.field public static final abc_dialog_title_material:I = 0x7f0c000c

.field public static final abc_expanded_menu_layout:I = 0x7f0c000d

.field public static final abc_list_menu_item_checkbox:I = 0x7f0c000e

.field public static final abc_list_menu_item_icon:I = 0x7f0c000f

.field public static final abc_list_menu_item_layout:I = 0x7f0c0010

.field public static final abc_list_menu_item_radio:I = 0x7f0c0011

.field public static final abc_popup_menu_header_item_layout:I = 0x7f0c0012

.field public static final abc_popup_menu_item_layout:I = 0x7f0c0013

.field public static final abc_screen_content_include:I = 0x7f0c0014

.field public static final abc_screen_simple:I = 0x7f0c0015

.field public static final abc_screen_simple_overlay_action_mode:I = 0x7f0c0016

.field public static final abc_screen_toolbar:I = 0x7f0c0017

.field public static final abc_search_dropdown_item_icons_2line:I = 0x7f0c0018

.field public static final abc_search_view:I = 0x7f0c0019

.field public static final abc_select_dialog_material:I = 0x7f0c001a

.field public static final design_bottom_navigation_item:I = 0x7f0c0032

.field public static final design_bottom_sheet_dialog:I = 0x7f0c0033

.field public static final design_layout_snackbar:I = 0x7f0c0034

.field public static final design_layout_snackbar_include:I = 0x7f0c0035

.field public static final design_layout_tab_icon:I = 0x7f0c0036

.field public static final design_layout_tab_text:I = 0x7f0c0037

.field public static final design_menu_item_action_area:I = 0x7f0c0038

.field public static final design_navigation_item:I = 0x7f0c0039

.field public static final design_navigation_item_header:I = 0x7f0c003a

.field public static final design_navigation_item_separator:I = 0x7f0c003b

.field public static final design_navigation_item_subheader:I = 0x7f0c003c

.field public static final design_navigation_menu:I = 0x7f0c003d

.field public static final design_navigation_menu_item:I = 0x7f0c003e

.field public static final design_text_input_password_icon:I = 0x7f0c003f

.field public static final notification_action:I = 0x7f0c0041

.field public static final notification_action_tombstone:I = 0x7f0c0042

.field public static final notification_media_action:I = 0x7f0c0043

.field public static final notification_media_cancel_action:I = 0x7f0c0044

.field public static final notification_template_big_media:I = 0x7f0c0045

.field public static final notification_template_big_media_custom:I = 0x7f0c0046

.field public static final notification_template_big_media_narrow:I = 0x7f0c0047

.field public static final notification_template_big_media_narrow_custom:I = 0x7f0c0048

.field public static final notification_template_custom_big:I = 0x7f0c0049

.field public static final notification_template_icon_group:I = 0x7f0c004a

.field public static final notification_template_lines_media:I = 0x7f0c004b

.field public static final notification_template_media:I = 0x7f0c004c

.field public static final notification_template_media_custom:I = 0x7f0c004d

.field public static final notification_template_part_chronometer:I = 0x7f0c004e

.field public static final notification_template_part_time:I = 0x7f0c004f

.field public static final select_dialog_item_material:I = 0x7f0c0050

.field public static final select_dialog_multichoice_material:I = 0x7f0c0051

.field public static final select_dialog_singlechoice_material:I = 0x7f0c0052

.field public static final support_simple_spinner_dropdown_item:I = 0x7f0c0053

.field public static final tooltip:I = 0x7f0c0054


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 926
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
