.class public final Landroid/support/constraint/R$attr;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/constraint/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "attr"
.end annotation


# static fields
.field public static final constraintSet:I = 0x7f040062

.field public static final layout_constraintBaseline_creator:I = 0x7f0400bf

.field public static final layout_constraintBaseline_toBaselineOf:I = 0x7f0400c0

.field public static final layout_constraintBottom_creator:I = 0x7f0400c1

.field public static final layout_constraintBottom_toBottomOf:I = 0x7f0400c2

.field public static final layout_constraintBottom_toTopOf:I = 0x7f0400c3

.field public static final layout_constraintDimensionRatio:I = 0x7f0400c4

.field public static final layout_constraintEnd_toEndOf:I = 0x7f0400c5

.field public static final layout_constraintEnd_toStartOf:I = 0x7f0400c6

.field public static final layout_constraintGuide_begin:I = 0x7f0400c7

.field public static final layout_constraintGuide_end:I = 0x7f0400c8

.field public static final layout_constraintGuide_percent:I = 0x7f0400c9

.field public static final layout_constraintHeight_default:I = 0x7f0400ca

.field public static final layout_constraintHeight_max:I = 0x7f0400cb

.field public static final layout_constraintHeight_min:I = 0x7f0400cc

.field public static final layout_constraintHorizontal_bias:I = 0x7f0400cd

.field public static final layout_constraintHorizontal_chainStyle:I = 0x7f0400ce

.field public static final layout_constraintHorizontal_weight:I = 0x7f0400cf

.field public static final layout_constraintLeft_creator:I = 0x7f0400d0

.field public static final layout_constraintLeft_toLeftOf:I = 0x7f0400d1

.field public static final layout_constraintLeft_toRightOf:I = 0x7f0400d2

.field public static final layout_constraintRight_creator:I = 0x7f0400d3

.field public static final layout_constraintRight_toLeftOf:I = 0x7f0400d4

.field public static final layout_constraintRight_toRightOf:I = 0x7f0400d5

.field public static final layout_constraintStart_toEndOf:I = 0x7f0400d6

.field public static final layout_constraintStart_toStartOf:I = 0x7f0400d7

.field public static final layout_constraintTop_creator:I = 0x7f0400d8

.field public static final layout_constraintTop_toBottomOf:I = 0x7f0400d9

.field public static final layout_constraintTop_toTopOf:I = 0x7f0400da

.field public static final layout_constraintVertical_bias:I = 0x7f0400db

.field public static final layout_constraintVertical_chainStyle:I = 0x7f0400dc

.field public static final layout_constraintVertical_weight:I = 0x7f0400dd

.field public static final layout_constraintWidth_default:I = 0x7f0400de

.field public static final layout_constraintWidth_max:I = 0x7f0400df

.field public static final layout_constraintWidth_min:I = 0x7f0400e0

.field public static final layout_editor_absoluteX:I = 0x7f0400e2

.field public static final layout_editor_absoluteY:I = 0x7f0400e3

.field public static final layout_goneMarginBottom:I = 0x7f0400e4

.field public static final layout_goneMarginEnd:I = 0x7f0400e5

.field public static final layout_goneMarginLeft:I = 0x7f0400e6

.field public static final layout_goneMarginRight:I = 0x7f0400e7

.field public static final layout_goneMarginStart:I = 0x7f0400e8

.field public static final layout_goneMarginTop:I = 0x7f0400e9

.field public static final layout_optimizationLevel:I = 0x7f0400ec


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
